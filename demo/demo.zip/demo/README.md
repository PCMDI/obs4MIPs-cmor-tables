
This demo must be run with CMOR 3.2.6 or a more recent version.

CMOR can be obtained via Anaconda at https://anaconda.org/PCMDI/cmor once the user has installed Anaconda (https://continuum.io)

More information about CMOR is available at: https://cmor.llnl.gov

If you have any difficulties, please contact us at obs4MIPs-admin@llnl.gov
